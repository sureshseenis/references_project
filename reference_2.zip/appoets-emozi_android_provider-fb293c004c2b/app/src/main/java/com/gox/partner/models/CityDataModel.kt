package com.gox.partner.models

data class CityDataModel(
        var id: String = "",
        var cityName: String = ""
)