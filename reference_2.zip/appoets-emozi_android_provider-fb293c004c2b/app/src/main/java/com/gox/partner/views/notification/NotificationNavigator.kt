package com.gox.partner.views.notification

interface NotificationNavigator