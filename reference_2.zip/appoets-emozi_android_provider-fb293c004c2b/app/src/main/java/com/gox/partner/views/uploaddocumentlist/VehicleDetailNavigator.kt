package com.gox.partner.views.uploaddocumentlist

interface VehicleDetailNavigator {
    fun gotoVerificationPage()
}
