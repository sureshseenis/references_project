package com.gox.partner.views.manage_payment

import androidx.lifecycle.MutableLiveData
import com.gox.base.base.BaseViewModel

class ManagePaymentViewModel : BaseViewModel<ManagePaymentNavigator>(){
    var razorID= MutableLiveData<String>()
}