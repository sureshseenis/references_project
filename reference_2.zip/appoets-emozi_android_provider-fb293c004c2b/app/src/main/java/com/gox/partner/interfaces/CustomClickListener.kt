package com.gox.partner.interfaces

internal interface CustomClickListener {
    fun onListClickListener()
}