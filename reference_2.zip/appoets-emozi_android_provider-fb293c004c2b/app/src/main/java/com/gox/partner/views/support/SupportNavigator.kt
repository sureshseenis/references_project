package com.gox.partner.views.support

interface SupportNavigator {

    fun goToPhoneCall()
    fun goToMail()
    fun goToWebsite()
}