package com.gox.partner.views.earnings

interface EarningsNavigator