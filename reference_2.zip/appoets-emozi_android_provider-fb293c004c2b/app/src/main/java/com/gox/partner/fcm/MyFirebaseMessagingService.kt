package com.gox.partner.fcm

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.google.gson.Gson
import com.gox.base.BuildConfig
import com.gox.base.base.BaseApplication
import com.gox.base.data.PreferencesKey
import com.gox.partner.R
import com.gox.partner.views.dashboard.DashBoardActivity

class MyFirebaseMessagingService : FirebaseMessagingService() {
    private lateinit var mUrlPersistence: SharedPreferences
    var notificationId = 0
    var notificationData: NotificationDataModel? = null
    override fun onNewToken(s: String) {
        @SuppressLint("HardwareIds") val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        Log.d("DEVICE_ID: ", deviceId)
        Log.d("FCM_TOKEN", s)
        mUrlPersistence = BaseApplication.run { getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE) }

        mUrlPersistence.edit().putString(PreferencesKey.DEVICE_TOKEN, s)
    }

    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */
// [START receive_message]
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        val intent = Intent(INTENT_FILTER)
        sendBroadcast(intent)

        Log.d("DDDPP",remoteMessage.data!!["custom"].toString())

        notificationData = Gson().fromJson(remoteMessage.data!!["custom"], NotificationDataModel::class.java)
        // [START_EXCLUDE]
// There are two types of messages data messages and notification messages. Data messages are handled
// here in onMessageReceived whether the app is in the foreground or background. Data messages are the type
// traditionally used with GCM. Notification messages are only received here in onMessageReceived when the app
// is in the foreground. When the app is in the background an automatically generated notification is displayed.
// When the user taps on the notification they are returned to the app. Messages containing both notification
// and data payloads are treated as notification messages. The Firebase console always sends notification
// messages. For more see: https://firebase.google.com/docs/cloud-messaging/concept-options
// [END_EXCLUDE]
// TODO(developer): Handle FCM messages here.
// Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        Log.d(TAG, "From: " + remoteMessage.from)
        Log.d(TAG, "Message data payload: " + remoteMessage.data)
        if (remoteMessage.data.size > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.data)
            sendNotification(remoteMessage.data["message"])
        }

        // Also if you intend on generating your own notifications as a result of a received FCM
// message, here is where that should be initiated. See sendNotification method below.
    }
    // [END receive_message]
    /**
     * Schedule a job using FirebaseJobDispatcher.
     */

    /**
     * Handle time allotted to BroadcastReceivers.
     */
    private fun handleNow() {
        Log.d(TAG, "Short lived task is done.")
    }

    /**
     * Create and show a simple notification containing the received FCM message.
     *
     * @param messageBody FCM message body received.
     */
    private fun sendNotification(messageBody: String?) {
        if (!isBackground(applicationContext)) { // app is in foreground, broadcast the push message
            // sendNotification(messageBody)
            if (messageBody.equals("New Incoming Ride", ignoreCase = true)
                    || messageBody.equals("New Incoming Order")
                    || messageBody.equals("New Incoming Order Request", ignoreCase = true)
                    || messageBody.equals("New Incoming Service Request", ignoreCase = true)
                    || messageBody.equals("New Incoming Courier Request", ignoreCase = true)
                    || messageBody.equals("RRRR")
                    || messageBody.equals("TRANSPORT", true)
                    || messageBody.equals("ORDER", true)
                    || messageBody.equals("SERVICE", true)) {
                setFullScreenViewIntent(messageBody)
            }else {
                showNotification(messageBody)
            }
        } else {
            // app is in background, show the notification in notification tray
            if (messageBody.equals("New Incoming Ride", ignoreCase = true)
                    || messageBody.equals("New Incoming Order")
                    || messageBody.equals("New Incoming Order Request", ignoreCase = true)
                    || messageBody.equals("New Incoming Service Request", ignoreCase = true)
                    || messageBody.equals("New Incoming Courier Request", ignoreCase = true)
                    || messageBody.equals("RRRR")
                    || messageBody.equals("TRANSPORT", true)
                    || messageBody.equals("ORDER", true)
                    || messageBody.equals("SERVICE", true)) {
                setFullScreenViewIntent(messageBody)
            }else{
                showNotification(messageBody)
            }
        }

    }

    private fun showNotification(messageBody: String?){
        val intentPendingIntent = Intent(applicationContext, DashBoardActivity::class.java)
        intentPendingIntent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        val bundle = Bundle()


        //Chat data passing
        if (notificationData?.message?.topic?.contains("chat", true)!!) {
            mUrlPersistence = BaseApplication.run { getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE) }
            mUrlPersistence.edit().putBoolean("chat_come", true).apply()

            intentPendingIntent.putExtra("chat_come", true)
            bundle.putBoolean("chat_come", true)
        }
        val pendingIntent = PendingIntent.getActivity(baseContext, 0, intentPendingIntent, PendingIntent.FLAG_UPDATE_CURRENT)

        val mBuilder = NotificationCompat.Builder(this, "PUSH")
        val inboxStyle = NotificationCompat.InboxStyle()
        inboxStyle.addLine(messageBody)
        val notificationTime = System.currentTimeMillis() // notification time
        // Sets an ID for the notification, so it can be updated.
        val channelId = "my_channel_01" // The id of the channel.
        val name: CharSequence = "Channel human readable title" // The user-visible name of the channel.
        val importance = NotificationManager.IMPORTANCE_HIGH
        val notification: Notification
        notification = mBuilder.setSmallIcon(R.mipmap.ic_launcher).setTicker(getString(R.string.app_name)).setWhen(notificationTime)
                .setAutoCancel(true)
                .setContentTitle(getString(R.string.app_name))
                .setContentIntent(pendingIntent)
                .setExtras(bundle)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .setStyle(NotificationCompat.BigTextStyle().bigText(messageBody))
                .setWhen(notificationTime)
                .setSmallIcon(getNotificationIcon(mBuilder))
                .setContentText(messageBody)
                .setChannelId(channelId)
                .setDefaults(Notification.DEFAULT_VIBRATE
                        or Notification.DEFAULT_LIGHTS)
                .build()
        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mChannel = NotificationChannel(channelId, name, importance)
            // Create a notification and set the notification channel.
            notificationManager.createNotificationChannel(mChannel)
        }
        notificationManager.notify(0, notification)
    }

    private fun setFullScreenViewIntent(messageBody: String?){
        val mainIntent = Intent(this, DashBoardActivity::class.java)
        mainIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK

        val mBuilder = NotificationCompat.Builder(this, "PUSH")
        val inboxStyle = NotificationCompat.InboxStyle()
        inboxStyle.addLine(messageBody)
        val `when` = System.currentTimeMillis() // notification time
        // Sets an ID for the notification, so it can be updated.
        val notifyID = 1
        val CHANNEL_ID = "INCOMING REQUEST" // The id of the channel.
        val name: CharSequence = "INCOMING REQUEST TAXI ORDER SERVICE COURIER" // The user-visible name of the channel.
        val importance = NotificationManager.IMPORTANCE_HIGH
        val pendingIntent = PendingIntent.getActivity(baseContext, notifyID, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT)
        val notification: Notification
        notification = mBuilder.setSmallIcon(R.mipmap.ic_launcher).setTicker(getString(R.string.app_name)).setWhen(`when`)
                .setAutoCancel(true)
                .setContentTitle(getString(R.string.app_name))
                .setContentIntent(pendingIntent)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .setStyle(NotificationCompat.BigTextStyle().bigText(messageBody))
                .setWhen(`when`)
                .setSmallIcon(getNotificationIcon(mBuilder))
                .setContentText(messageBody)
                .setChannelId(CHANNEL_ID)
                .setFullScreenIntent(pendingIntent, true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setOngoing(true)
                .setLights(Color.GREEN, 1000, 1000)
                .build()
        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mChannel = NotificationChannel(CHANNEL_ID, name, importance)
            // Create a notification and set the notification channel.
            notificationManager.createNotificationChannel(mChannel)
        }
        notificationManager.notify(notifyID, notification)
    }

    private fun getNotificationIcon(notificationBuilder: NotificationCompat.Builder): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            notificationBuilder.color = ContextCompat.getColor(applicationContext, R.color.colorPrimary)
            R.drawable.ic_push
        } else {
            R.mipmap.ic_launcher
        }
    }

    private fun isBackground(context: Context): Boolean {
        var isInBackground = true
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val runningProcesses = am.runningAppProcesses
        for (processInfo in runningProcesses)
            if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND)
                for (activeProcess in processInfo.pkgList)
                    if (activeProcess == context.packageName) isInBackground = false
        return isInBackground
    }

    private fun isCallActive(context: Context): Boolean {
        val manager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return manager.mode == AudioManager.MODE_IN_CALL
    }

    private fun isLocked(context: Context): Boolean {
        val myKM = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return myKM.isKeyguardLocked
    }

    companion object {
        private const val TAG = "MyFirebaseMsgService"
        const val INTENT_FILTER = "INTENT_FILTER"
    }
}