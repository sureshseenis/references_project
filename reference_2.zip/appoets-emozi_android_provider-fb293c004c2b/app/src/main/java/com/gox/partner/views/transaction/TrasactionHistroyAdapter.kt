package com.gox.partner.views.transaction

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.gox.partner.R
import com.gox.partner.databinding.TransactionListItemBinding
import com.gox.partner.models.WalletTransaction

class TrasactionHistroyAdapter(context: Context, transactionList: List<WalletTransaction.ResponseData.Data.TransactionDes>, val currencySymbol: String)
: RecyclerView.Adapter<TrasactionHistroyAdapter.MyViewHolder>() {

    var context: Context? = null
    var transactionList: List<WalletTransaction.ResponseData.Data.TransactionDes>? = null

    init {
        this.context = context
        this.transactionList = transactionList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        val layoutInflater = LayoutInflater.from(parent.context)

        var view= MyViewHolder(DataBindingUtil.inflate(LayoutInflater.from(parent.context),
                R.layout.transaction_list_item, parent, false))

        return view
    }

    override fun getItemCount(): Int {
        return transactionList!!.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.mBinding.tvTransactionID.text = transactionList!![position].transaction_desc
        holder.mBinding.tvDate.text = ""
        holder.mBinding.tvDate.isSelected = true

        //Heade background color set
        context?.resources?.getColor(R.color.white)?.let { holder.mBinding.parentView.setBackgroundColor(it) }

//        var strDate = CommanMethods.getLocalTimeStamp(transactionList!![position].created_at)
        holder.mBinding.tvTransactionAmount.text =  currencySymbol+" " + String.format(context!!.getString(R.string.transaction_amount), transactionList!!.get(position).amount)
        if (transactionList!![position].type == "D") {
            holder.mBinding.tvTransactionStatus.text = context!!.resources.getString(R.string.depited)
            holder.mBinding.tvTransactionStatus.setTextColor(ContextCompat.getColor(context!!,
                    R.color.dispute_status_open))
        } else if (transactionList!![position].type == "C"){
            holder.mBinding.tvTransactionStatus.text = context!!.resources.getString(R.string.credited)
            holder.mBinding.tvTransactionStatus.setTextColor(ContextCompat.getColor(context!!,
                    R.color.credit))
        } else if(transactionList!![position].type == "E"){
            holder.mBinding.tvTransactionStatus.text = context!!.resources.getString(R.string.earned)
            holder.mBinding.tvTransactionStatus.setTextColor(ContextCompat.getColor(context!!,
                    R.color.credit))
        }
    }

    inner class MyViewHolder(itemView: TransactionListItemBinding) : RecyclerView.ViewHolder(itemView.root) {
        val mBinding = itemView
    }

    private fun openDialog(view: View) {
        var alertDialog = AlertDialog.Builder(context)

    }

}