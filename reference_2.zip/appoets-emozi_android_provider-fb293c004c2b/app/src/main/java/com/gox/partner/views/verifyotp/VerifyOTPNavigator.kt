package com.gox.app.ui.verifyotp

interface VerifyOTPNavigator{
    fun verifyOTP()
}