package com.gox.partner.views.set_service_category_price

interface SetServicePriceNavigator {
    fun showError(error: String)
}