/*
package com.gox.partner.views.currentorder_fragment

interface CurrentOrderNavigator*/
