package com.gox.partner.views.pendinglist

import android.view.View

interface PendingListNavigator {
    fun pickItem(view: View)
}