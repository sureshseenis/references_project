package com.gox.partner.models

class ContactNumberModel {
    var number: String = ""
}
