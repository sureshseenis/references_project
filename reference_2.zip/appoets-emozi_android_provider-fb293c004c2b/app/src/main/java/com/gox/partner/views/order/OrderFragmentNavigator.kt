package com.gox.partner.views.order

interface OrderFragmentNavigator {
    fun goToCurrentOrder()
    fun goToPastOrder()
    fun goToUpcomingOrder()
    fun opeFilterLayout()
}