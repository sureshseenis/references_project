package com.gox.partner.views.adapters

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.gox.partner.R
import com.gox.partner.databinding.TransactionListItemBinding
import com.gox.partner.models.WalletTransaction
import com.gox.partner.utils.CommonMethods
import com.gox.partner.views.transaction.TrasactionHistroyAdapter

class TransactionListAdapter(context: Context, transactionList: ArrayList<WalletTransaction.ResponseData.Data>)
    : RecyclerView.Adapter<TransactionListAdapter.MyViewHolder>() {

    var context: Context? = null
    var transactionList: List<WalletTransaction.ResponseData.Data>? = null

    //Multiple recycler view in scrap view
    private val viewPool = RecyclerView.RecycledViewPool()

    init {
        this.context = context
        this.transactionList = transactionList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(DataBindingUtil.inflate(LayoutInflater.from(parent.context),
                R.layout.transaction_list_item, parent, false))
    }

    override fun getItemCount(): Int {
        return transactionList!!.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.mBinding.tvTransactionID.text = transactionList!![position].transaction_alias
        holder.mBinding.tvDate.visibility = View.VISIBLE
        holder.mBinding.tvDate.text = transactionList!![position].created_time
        holder.mBinding.tvDate.isSelected = true
        context?.resources?.getColor(R.color.grey)?.let { holder.mBinding.parentView.setBackgroundColor(it) }

        holder.mBinding.tvTransactionAmount.visibility = View.GONE
        holder.mBinding.tvTransactionStatus.visibility = View.GONE

        if (!transactionList!![position].transactions.isNullOrEmpty()) {
            holder.mBinding.transactionListSubRv.apply {

                //Add the earning when provider deliver order
                if (transactionList!![position].store_orders != null) {
                    if (!transactionList!![position].transactions?.contains(WalletTransaction.ResponseData.Data.TransactionDes("Delivery Fare", "E", transactionList!![position].store_orders?.order_invoice?.delivery_amount!!))!!) {
                        //Delivery amount not equal 0.0 only list have details
                        if (transactionList!![position].store_orders?.order_invoice?.delivery_amount != 0.0){
                            transactionList!![position].transactions?.also {
                                it?.add(WalletTransaction.ResponseData.Data.TransactionDes("Delivery Fare", "E", transactionList!![position].store_orders?.order_invoice?.delivery_amount!!))
                            }
                        }
                    }
                }
                adapter = TrasactionHistroyAdapter(context!!, transactionList!![position].transactions!!, transactionList!!.get(position).provider.currency_symbol)
                setRecycledViewPool(viewPool)
            }
            holder.mBinding.transactionListSubRv.visibility = View.VISIBLE
        }

//        var strDate = CommanMethods.getLocalTimeStamp(transactionList!![position].created_at)
        holder.mBinding.tvTransactionAmount.text = transactionList!!.get(position).provider.currency_symbol + " " + String.format(context!!.getString(R.string.transaction_amount), transactionList!!.get(position).amount)
        if (transactionList!![position].type == "D") {
            holder.mBinding.tvTransactionStatus.text = context!!.resources.getString(R.string.depited)
            holder.mBinding.tvTransactionStatus.setTextColor(ContextCompat.getColor(context!!,
                    R.color.dispute_status_open))
        } else {
            holder.mBinding.tvTransactionStatus.text = context!!.resources.getString(R.string.credited)
            holder.mBinding.tvTransactionStatus.setTextColor(ContextCompat.getColor(context!!,
                    R.color.credit))
        }

    }

    inner class MyViewHolder(itemView: TransactionListItemBinding) : RecyclerView.ViewHolder(itemView.root) {
        val mBinding = itemView
    }

    private fun openDialog(view: View) {
        var alertDialog = AlertDialog.Builder(context)

    }

}