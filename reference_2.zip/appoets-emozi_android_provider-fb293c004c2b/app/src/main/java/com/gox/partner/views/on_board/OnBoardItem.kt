package com.gox.partner.views.on_board

class OnBoardItem(
        var imageID: Int = 0,
        var title: String? = null,
        var description: String? = null
)
