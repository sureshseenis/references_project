package com.gox.partner.views.edit_service_price

import com.gox.base.base.BaseViewModel

class EditServicePriceViewModel : BaseViewModel<EditServicePriceNavigator>()