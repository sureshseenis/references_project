package com.gox.partner.views.verifyfile

interface VerifyFileNavigator {
    fun gotoDashBoardPage()
}
