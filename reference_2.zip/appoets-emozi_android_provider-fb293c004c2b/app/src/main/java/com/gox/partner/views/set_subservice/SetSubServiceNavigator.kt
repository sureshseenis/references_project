package com.gox.partner.views.set_subservice

interface SetSubServiceNavigator