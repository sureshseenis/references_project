package com.gox.partner.views.privacypolicy

interface PrivacyNavigator