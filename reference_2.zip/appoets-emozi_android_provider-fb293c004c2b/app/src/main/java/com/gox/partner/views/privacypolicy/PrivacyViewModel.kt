package com.gox.partner.views.privacypolicy

import com.gox.base.base.BaseViewModel

class PrivacyViewModel : BaseViewModel<PrivacyNavigator>()