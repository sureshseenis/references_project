package com.gox.partner.models

class AddVehicleDataModel {
    var vehicleImage: String? = ""
    var id: Int? = 0
    var vehicleId: Int? = 0
    var vehicleModel: String? = ""
    var vehicleYear: String? = ""
    var vehicleColor: String? = ""
    var vehicleNumber: String? = ""
    var vehicleMake: String? = ""
    var vehicleRcBook: String? = ""
    var vehicleInsurance: String? = ""
    var wheelChair: Int = 0
    var childSeat: Int = 0
}