package com.gox.partner.views.countrylist

interface CountryNavigator {
    fun closeActivity()
}