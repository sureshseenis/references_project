package com.gox.partner.views.set_service

interface SetServiceNavigator