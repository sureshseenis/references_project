package com.gox.partner.views.account

interface AccountNavigator {
    fun onMenuItemClicked(position: Int)
}