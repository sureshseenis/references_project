package com.gox.partner.views.language

interface LanguageNavigator {
    fun onLanguageChanged()
}