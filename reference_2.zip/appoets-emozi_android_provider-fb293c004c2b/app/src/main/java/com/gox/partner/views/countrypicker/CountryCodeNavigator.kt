package com.gox.partner.views.countrypicker

interface CountryCodeNavigator {
    fun closeActivity()
}