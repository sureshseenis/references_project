package com.gox.partner.fcm

import android.annotation.SuppressLint
import android.app.*
import android.app.ActivityManager.RunningAppProcessInfo
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.google.gson.Gson
import com.gox.base.BuildConfig
import com.gox.base.base.BaseApplication
import com.gox.base.data.PreferencesHelper
import com.gox.base.data.PreferencesKey
import com.gox.partner.R
import com.gox.partner.views.splash.SplashActivity


class FcmService : FirebaseMessagingService() {

    private var notificationId = 100
    private var TAG = "onMessageReceived"
    private var player: MediaPlayer? = null

    private lateinit var mUrlPersistence: SharedPreferences

    @SuppressLint("CommitPrefEdits")
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        mUrlPersistence = BaseApplication.run { getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE) }
        mUrlPersistence.edit().putString(PreferencesKey.DEVICE_TOKEN, token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        wakeUpScreen()
        val notificationData = Gson().fromJson(remoteMessage.data!!["custom"], NotificationDataModel::class.java)
        println(TAG + "onMessageReceived = $notificationData")


        if (notificationData.message!!.notification!!.body!!.contains("New Incoming Ride")
                || notificationData.message!!.notification!!.body!!.contains("New Incoming Order Request")
                || notificationData.message!!.notification!!.body!!.contains("New Incoming Service Request")
                || notificationData.message!!.notification!!.body!!.contains("New Incoming Courier Request")
                || notificationData.message!!.notification!!.body!!.contains("New Incoming Delivery Request")
                || notificationData.message!!.notification!!.body!!.contains("RRRR")
                || notificationData.message!!.notification!!.body!!.contains("TRANSPORT", true)
                || notificationData.message!!.notification!!.body!!.contains("ORDER", true)
                || notificationData.message!!.notification!!.body!!.contains("SERVICE", true)) {
            if (!isAppIsInBackground(applicationContext)) { // app is in foreground, broadcast the push message
                sendProlongedNotification(notificationData)
            } else {
                val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                val kl = km.newKeyguardLock("IN")
                val mainIntent = Intent(this, SplashActivity::class.java)
                if (notificationData?.message?.topic?.contains("chat", true)!!) {
                    mUrlPersistence = BaseApplication.run { getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE) }
                    mUrlPersistence.edit().putBoolean("chat_come", true).apply()
                    mainIntent.putExtra("chat_come", true)
                }
                mainIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(mainIntent)
            }
        } else sendNotification(notificationData)

        if (notificationData.message!!.notification!!.body!!.contains("New Incoming Ride")
                && !isBackground(applicationContext)
                && !isLocked(applicationContext)
                && !isCallActive(applicationContext) && !PreferencesHelper
                        .get(PreferencesKey.ACCESS_TOKEN, "")
                        .equals("")) restartApp()
    }

    private fun sendNotification(notificationData: NotificationDataModel) {

        val intent = Intent(this, SplashActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

        //Chat data passing
        if (notificationData?.message?.topic?.contains("chat", true)!!) {
            mUrlPersistence = BaseApplication.run { getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE) }
            mUrlPersistence.edit().putBoolean("chat_come", true).apply()

            intent.putExtra("chat_come", true)
            //intent.putExtra("chat_come", true)
        }

        val pendingIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_ONE_SHOT)


        val channelId = getString(R.string.app_name)
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_push)
                .setColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
                .setContentTitle(notificationData.message!!.notification!!.title)
                .setContentText(notificationData.message!!.notification!!.body)
                .setAutoCancel(true)
                //    .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent)

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) notificationManager.createNotificationChannel(
                NotificationChannel(channelId, getString(R.string.app_name), NotificationManager.IMPORTANCE_DEFAULT))

        notificationManager.notify(notificationId, notificationBuilder.build())


        /*val intent = Intent(this, SplashActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_ONE_SHOT)

        val channelId = getString(R.string.app_name)
        val soundUri: Uri = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + applicationContext.packageName + "/" + R.raw.alert_tone)
        Log.e("SCHEME_ANDROID_RESOURCE", soundUri.toString())
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationChannel = NotificationChannel(channelId, getString(R.string.app_name), NotificationManager.IMPORTANCE_DEFAULT)
            notificationChannel.lightColor = Color.GRAY
            notificationChannel.enableLights(true)
            val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build()
            notificationChannel.setSound(soundUri, audioAttributes)
            notificationManager.createNotificationChannel(notificationChannel)
        }

        val notificationBuilder = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.push)
                .setContentTitle(notificationData.message!!.notification!!.title)
                .setContentText(notificationData.message!!.notification!!.body)
                .setAutoCancel(true)
                .setSound(soundUri)
                .setContentIntent(pendingIntent)

        val mNotification = notificationBuilder.build()
        mNotification.flags = Notification.DEFAULT_LIGHTS or Notification.FLAG_AUTO_CANCEL or Notification.DEFAULT_SOUND

        notificationManager.notify(notificationId, mNotification)*/


    }

    private fun sendProlongedNotification(notificationData: NotificationDataModel) {
        println(TAG + "sendProlongedNotification = $notificationData")

        val alarmSound = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + packageName + "/raw/alert_tone")
        val intent = Intent(this, SplashActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        //Chat data passing
        if (notificationData?.message?.topic?.contains("chat", true)!!) {
            mUrlPersistence = BaseApplication.run { getSharedPreferences(BuildConfig.APPLICATION_ID, Context.MODE_PRIVATE) }
            mUrlPersistence.edit().putBoolean("chat_come", true).apply()
            intent.putExtra("chat_come", true)
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT)
        val channelId = getString(R.string.app_name)


        /*   try {
               //val r = RingtoneManager.getRingtone(applicationContext, alarmSound)
               //val notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
               player = MediaPlayer.create(this, alarmSound)
               player!!.isLooping = true
               player!!.start()
               // r.play()
           } catch (e: Exception) {
               e.printStackTrace()
           }*/
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationBuilder = NotificationCompat.Builder(this, channelId)
                    .setSmallIcon(R.drawable.ic_push)
                    .setContentTitle(notificationData.message!!.notification!!.title)
                    .setAutoCancel(true)
                    .setContentIntent(pendingIntent)
                    .setDefaults(Notification.DEFAULT_ALL)
            val mNotification = notificationBuilder.build()
            val importance = NotificationManager.IMPORTANCE_HIGH
            val notificationChannel = NotificationChannel(channelId, getString(R.string.app_name), importance)
            notificationChannel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            //  notificationChannel.setSound(alarmSound, audioAttributes)
            notificationChannel.setShowBadge(true)
            notificationChannel.description = notificationData.message!!.notification!!.body
            notificationChannel.enableLights(true)
            notificationChannel.lightColor = Color.YELLOW
            notificationChannel.enableVibration(true)
            notificationChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
            notificationManager.createNotificationChannel(notificationChannel)
            notificationManager.notify(notificationId, mNotification)
        } else {
            val notificationBuilder = NotificationCompat.Builder(this, channelId)
                    .setSmallIcon(R.drawable.ic_push)
                    .setContentTitle(notificationData.message!!.notification!!.title)
                    .setContentText(notificationData.message!!.notification!!.body)
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentIntent(pendingIntent)
                    //   .setSound(alarmSound)
                    .setDefaults(Notification.DEFAULT_ALL)
            val mNotification = notificationBuilder.build()
            notificationManager.notify(notificationId, mNotification)
        }

    }


    private fun wakeUpScreen() {
        val pm = this.getSystemService(Context.POWER_SERVICE) as PowerManager
        val isScreenOn = pm.isScreenOn
        Log.e("screen on......", "" + isScreenOn)
        if (!isScreenOn) {
            @SuppressLint("InvalidWakeLockTag") val wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "MyLock")
            wl.acquire(10000)
            @SuppressLint("InvalidWakeLockTag") val wl_cpu = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyCpuLock")
            wl_cpu.acquire(10000)
        }
    }


    private fun isBackground(context: Context): Boolean {
        var isInBackground = true
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val runningProcesses = am.runningAppProcesses
        for (processInfo in runningProcesses)
            if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND)
                for (activeProcess in processInfo.pkgList)
                    if (activeProcess == context.packageName) isInBackground = false
        return isInBackground
    }

    private fun isCallActive(context: Context): Boolean {
        val manager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return manager.mode == AudioManager.MODE_IN_CALL
    }

    private fun isLocked(context: Context): Boolean {
        val myKM = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return myKM.isKeyguardLocked
    }

    private fun restartApp() {
        println(TAG + "RRR push notificationData = RESTART")
        val intent = Intent(this, SplashActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (player != null) {
            player!!.stop()
        }
    }

    fun isAppIsInBackground(context: Context): Boolean {
        var isInBackground = true
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT_WATCH) {
            val runningProcesses = am.runningAppProcesses
            for (processInfo in runningProcesses) {
                if (processInfo.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    for (activeProcess in processInfo.pkgList) {
                        if (activeProcess == context.packageName) {
                            isInBackground = false
                        }
                    }
                }
            }
        } else {
            val taskInfo = am.getRunningTasks(1)
            val componentInfo = taskInfo[0].topActivity
            if (componentInfo?.packageName == context.packageName) {
                isInBackground = false
            }
        }
        return isInBackground
    }
}