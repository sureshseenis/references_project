package com.gox.partner.views.transaction

interface TransactionNavigator