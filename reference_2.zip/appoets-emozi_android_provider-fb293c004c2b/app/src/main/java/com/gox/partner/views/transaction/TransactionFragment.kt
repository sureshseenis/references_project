package com.gox.partner.views.transaction

import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.databinding.ViewDataBinding
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gox.base.base.BaseFragment
import com.gox.base.extensions.observeLiveData
import com.gox.base.utils.ViewUtils
import com.gox.partner.R
import com.gox.partner.databinding.FragmentTransactionBinding
import com.gox.partner.models.WalletTransaction
import com.gox.partner.views.adapters.TransactionListAdapter
import es.dmoral.toasty.Toasty
import kotlinx.android.synthetic.main.fragment_transaction.*


class TransactionFragment : BaseFragment<FragmentTransactionBinding>(), TransactionNavigator {

    private lateinit var mBinding: FragmentTransactionBinding
    private lateinit var mViewModel: TransactionViewModel

    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var transactionListAdapter: TransactionListAdapter
    var pageNo = 1
    var currentPage = 1
    private val transactionList: ArrayList<WalletTransaction.ResponseData.Data>? = arrayListOf()

    override fun getLayoutId() = R.layout.fragment_transaction

    override fun initView(mRootView: View?, mViewDataBinding: ViewDataBinding?) {
        mBinding = mViewDataBinding as FragmentTransactionBinding
        mViewModel = TransactionViewModel()
        mViewModel.navigator = this
        mBinding.transctionmodel = mViewModel
        linearLayoutManager = LinearLayoutManager(activity)
        mBinding.transactionListRv.layoutManager = linearLayoutManager
        mBinding.lifecycleOwner = this
        mViewModel.showLoading = loadingObservable as MutableLiveData<Boolean>
        getApiResponse()

        pageNo=1

        transactionListAdapter = TransactionListAdapter(activity!!, transactionList!!)
        mBinding.transactionListRv.adapter = transactionListAdapter

       transactionList?.clear()
        mBinding.tvLoadMode.setOnClickListener {
          //  if (pageNo != currentPage)
                mViewModel.callTransactionApi(pageNo)
        }

        mBinding.transactionListRv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (!recyclerView.canScrollVertically(1) && newState == RecyclerView.SCROLL_STATE_IDLE) {
                    Log.d("-----", "end")
                    mViewModel.callTransactionApi(pageNo)
                }
            }
        })
    }

    private fun getApiResponse() {
        observeLiveData(mViewModel.transactionLiveResponse) {
            if(transactionList?.size ==0){
                if (it.responseData.data.isNotEmpty()) {
                    contentMain.visibility = View.VISIBLE
                    llEmptyView.visibility = View.GONE
                } else {
                    contentMain.visibility = View.GONE
                    llEmptyView.visibility = View.VISIBLE
                }
            }

            if (mViewModel.transactionLiveResponse.value!!.responseData.data!!.size !=0) {
                pageNo += 1
                currentPage=pageNo
                transactionList?.addAll(mViewModel.transactionLiveResponse.value!!.responseData.data!!)
                transactionListAdapter.notifyDataSetChanged()
                mBinding.tvLoadMode.visibility=View.VISIBLE
            }else{
              //  Toasty.error(context!!,getString(R.string.you_have_no_past_records),Toast.LENGTH_SHORT).show()
            }
        }

        observeLiveData(mViewModel.errorResponse) {
            ViewUtils.showToast(activity!!, it, false)
            contentMain.visibility = View.GONE
            llEmptyView.visibility = View.VISIBLE
        }
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)
        if (isVisibleToUser)
            mViewModel.callTransactionApi(pageNo)
    }
}