package com.gox.partner.views.adapters

interface ReasonListClickListener {
    fun reasonOnItemClick(disputeName: String)
}