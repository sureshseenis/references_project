package com.gox.partner.views.manage_payment

import android.util.Log
import android.widget.Toast
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import com.google.android.material.tabs.TabLayout
import com.gox.base.base.BaseActivity
import com.gox.partner.R
import com.gox.partner.databinding.ActivityManagePaymentBinding
import com.gox.partner.views.adapters.PaymentAdapter
import com.gox.partner.views.transaction.TransactionFragment
import com.gox.partner.views.wallet.WalletFragment
import com.razorpay.PaymentResultListener
import es.dmoral.toasty.Toasty
import java.util.*

class ManagePaymentActivity : BaseActivity<ActivityManagePaymentBinding>(), ManagePaymentNavigator, PaymentResultListener {

    private lateinit var mBinding: ActivityManagePaymentBinding
    private lateinit var mViewModel: ManagePaymentViewModel
    private lateinit var paymentAdapter: PaymentAdapter
    private lateinit var tbManagePayment: TabLayout

    override fun getLayoutId() = R.layout.activity_manage_payment


    override fun initView(mViewDataBinding: ViewDataBinding?) {
        mBinding = mViewDataBinding as ActivityManagePaymentBinding
        mViewModel = ViewModelProviders.of(this).get(ManagePaymentViewModel::class.java)
        mViewModel.navigator = this
        tbManagePayment = findViewById(R.id.tb_payment)
        mBinding.toolbarLayout.tvToolbarTitle.text = resources.getString(com.gox.partner.R.string.header_label_payment)
        mBinding.toolbarLayout.ivToolbarBack.setOnClickListener {
            finish()
        }

        val paymentFragmentList = Vector<Fragment>()

        val walletFragment = WalletFragment()
        val transactionFragment = TransactionFragment()

        paymentFragmentList.add(walletFragment)
        paymentFragmentList.add(transactionFragment)

        paymentAdapter = PaymentAdapter(supportFragmentManager, this@ManagePaymentActivity, paymentFragmentList)
        mBinding.vbPayment.adapter = paymentAdapter
        tbManagePayment.setupWithViewPager(mBinding.vbPayment)

    }

    override fun onPaymentError(p0: Int, p1: String?) {
        Log.d("Payment Error Msg", "" + p1)
        Toasty.error(this, "$p1", Toast.LENGTH_SHORT).show()
    }

    override fun onPaymentSuccess(razPaymentID: String?) {
        mViewModel.razorID.value = razPaymentID
    }

}