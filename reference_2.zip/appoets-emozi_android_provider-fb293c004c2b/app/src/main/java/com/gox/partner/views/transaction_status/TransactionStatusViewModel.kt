package com.gox.partner.views.transaction_status

import com.gox.base.base.BaseViewModel

open class TransactionStatusViewModel : BaseViewModel<TransactionStatusNavigator>()