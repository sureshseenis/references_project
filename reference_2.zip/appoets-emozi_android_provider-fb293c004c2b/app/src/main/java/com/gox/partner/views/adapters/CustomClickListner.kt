package com.gox.partner.views.adapters

public interface CustomClickListner {
    fun onListClickListner()
}
