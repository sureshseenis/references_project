package com.gox.partner.views.manage_documents

interface ManageDocumentsNavigator {
    fun showError(error: String)
}