package com.gox.partner.views.on_board

interface OnBoardNavigator {
    fun goToSignIn()
    fun goToSignUp()
}