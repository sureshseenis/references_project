package com.gox.partner.models

data class AccountMenuModel(val text: String, val resId: Int)