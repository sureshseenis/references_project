package com.gox.partner.views.pastorder_fragment

interface PastOrderNavigator {

    fun gotoDetailPage()
}