package com.gox.partner.views.manage_payment

interface ManagePaymentNavigator