package com.gox.partner.models

data class ManageServicesDataModel(
        val colorResId: Int,
        val iconResId: Int,
        val title: String,
        val description: String
)