package com.gox.partner.interfaces

interface ServiceTypeListener {
    fun getServiceType(serviceType: String, serviceTypeID: Int,position:Int)
}