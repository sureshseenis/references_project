package com.gox.partner.views.citylist

interface CityListNavigator {
    fun closeActivity()
}