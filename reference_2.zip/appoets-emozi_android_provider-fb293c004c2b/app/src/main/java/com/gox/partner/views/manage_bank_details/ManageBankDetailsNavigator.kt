package com.gox.partner.views.manage_bank_details

interface ManageBankDetailsNavigator {

    fun validateDetails(): Boolean

}