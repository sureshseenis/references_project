package com.gox.partner.views.on_board

class WalkThrough(var drawable: Int, var title: String, var description: String)
