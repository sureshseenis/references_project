package com.gox.base.base

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.gox.base.extensions.observeLiveData
import com.gox.base.utils.LocaleUtils
import com.gox.base.utils.PermissionUtils
import com.gox.base.views.CustomDialog

abstract class BaseDialogFragment<T : ViewDataBinding> : DialogFragment() {

    private lateinit var mViewDataBinding: T
    private lateinit var rootView: View
    private var mActivity: FragmentActivity? = null
    private val loadingLiveData = MutableLiveData<Boolean>(false)
    private var customDialog: CustomDialog? = null
    protected val mPermissionUtils: PermissionUtils? = null


    val loadingObservable: MutableLiveData<Boolean> get() = loadingLiveData
    abstract fun initView(viewDataBinding: ViewDataBinding, view: View)

    fun getPermissionUtil(): PermissionUtils {
        return mPermissionUtils ?: PermissionUtils()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        LocaleUtils.setLocale(context)
        mActivity = activity
    }

    @LayoutRes
    protected abstract fun getLayout(): Int

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        mViewDataBinding = DataBindingUtil.inflate(inflater, getLayout(), container, false)
        rootView = mViewDataBinding.root
        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        customDialog = CustomDialog(mActivity!!, true)
        initView(mViewDataBinding, rootView)

        loadingObservable.observe(this, Observer {
            if (it) showLoading() else hideLoading()
        })
    }

    protected fun showLoading() {
        if (customDialog!!.window != null && !customDialog!!.isShowing) {
            customDialog!!.window!!.setBackgroundDrawableResource(android.R.color.transparent)
            customDialog!!.show()
        }
    }

    protected fun hideLoading() {
        if (customDialog!!.isShowing) {
            customDialog!!.dismiss()
        }

    }
}
