package com.gox.base.chatmessage

class ChatSocketResponseModel {
    var type: String? = ""
    var user: String? = ""
    var provider: String? = ""
    var message: String? = ""
}