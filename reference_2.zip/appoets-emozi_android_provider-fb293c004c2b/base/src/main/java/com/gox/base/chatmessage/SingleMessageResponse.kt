package com.gox.base.chatmessage

class SingleMessageResponse {
    var statusCode: String? = null
    var title: String? = null
    var message: String? = null
}