package com.gox.base.chatmessage

interface ChatNavigator