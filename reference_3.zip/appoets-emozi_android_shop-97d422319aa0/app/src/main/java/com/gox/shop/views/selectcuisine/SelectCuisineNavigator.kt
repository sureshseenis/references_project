package com.gox.shop.views.selectcuisine

interface  SelectCuisineNavigator {
}