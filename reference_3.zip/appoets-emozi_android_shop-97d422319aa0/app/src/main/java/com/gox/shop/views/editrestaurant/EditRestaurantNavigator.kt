package com.gox.shop.views.editrestaurant

interface EditRestaurantNavigator {

   fun validateInputs():Boolean
   fun showError(errorMsg:String)
   fun openCountryPicker()




}