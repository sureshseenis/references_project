package com.gox.app.ui.countrypicker

import com.gox.shop.base.BaseViewModel

class CountryCodeViewModel : BaseViewModel<CountrtCodeNavigator>() {

    fun closeActivity() {
        navigator.closeActivity()
    }

}