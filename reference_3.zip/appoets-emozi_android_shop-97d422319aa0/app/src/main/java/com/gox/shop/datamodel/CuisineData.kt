package com.gox.shop.datamodel

data class CuisineData(
    val id: Int,
    val name: String,
    val status: Int,
    val store_type_id: Int
)