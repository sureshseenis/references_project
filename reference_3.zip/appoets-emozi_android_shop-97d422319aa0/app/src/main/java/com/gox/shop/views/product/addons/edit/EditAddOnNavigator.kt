package com.gox.shop.views.product.addons.edit

interface EditAddOnNavigator {
    fun EditAddOnFunction()
}