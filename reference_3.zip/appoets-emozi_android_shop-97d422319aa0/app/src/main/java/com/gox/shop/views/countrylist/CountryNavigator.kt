package com.gox.shop.views.countrylist

interface CountryNavigator {
    fun closeActivity()
}