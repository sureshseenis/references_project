package com.gox.shop.datamodel

data class ZoneData(
    val city_id: Int,
    val company_id: Int,
    val id: Int,
    val name: String,
    val status: String,
    val user_type: String
)