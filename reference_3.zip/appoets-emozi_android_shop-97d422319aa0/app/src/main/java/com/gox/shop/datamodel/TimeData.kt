package com.gox.shop.datamodel

data class TimeData(
    val id: Int,
    val store_day: String,
    val store_end_time: String,
    val store_id: Int,
    val store_start_time: String
)