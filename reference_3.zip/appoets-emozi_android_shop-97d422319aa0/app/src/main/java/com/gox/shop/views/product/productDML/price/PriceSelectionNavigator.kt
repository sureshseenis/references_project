package com.gox.shop.views.product.productDML.price

interface PriceSelectionNavigator {
}