package com.gox.shop.datamodel

data class CountryModel(val code: String, val name: String, val dialCode: String, val flag: Int) {

}
