package com.gox.app.ui.countrypicker

interface CountrtCodeNavigator {
    fun closeActivity()
}