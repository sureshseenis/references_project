package com.gox.shop.views.history.historypast

interface  FragmentPastNavigator {

}