package com.gox.shop.views.history.historyongoing

interface  FragmentOngoingNavigator {

}