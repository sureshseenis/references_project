package com.gox.shop.views.product.category.create

interface CreateCategroyNavigator {
    fun selectImage()
    fun createCategoryMethod()
}