package com.gox.shop.datamodel

data class EditTimeModel(val day :String,val resId: Int) {



}