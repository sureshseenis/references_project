package com.gox.shop.views.accept

interface AcceptOrderNavigator {
    fun closeDialogWithPreparetime()
    fun closeDialogWithoutTime()
}