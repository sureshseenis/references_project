package com.gox.shop.views.orders.incoming

interface  IncomingNavigator {
    fun showError(message:String,statusCode:Int)
}