package com.gox.shop.views.history.historymain

import com.gox.shop.base.BaseViewModel

class  HistoryMainViewModel:BaseViewModel<HistorymainNavigator>(){

}