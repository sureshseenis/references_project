package com.gox.shop.views.product.categorySelection

interface CategorySelectionNavigator {
}