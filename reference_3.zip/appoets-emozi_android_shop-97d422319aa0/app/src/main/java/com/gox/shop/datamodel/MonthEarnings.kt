package com.gox.shop.datamodel

data class MonthEarnings(
    var total_amount: Any = Any()
)