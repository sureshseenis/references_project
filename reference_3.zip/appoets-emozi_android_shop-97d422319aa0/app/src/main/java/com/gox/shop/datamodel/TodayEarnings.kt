package com.gox.shop.datamodel

data class TodayEarnings(
    var total_amount: Any = Any()
)