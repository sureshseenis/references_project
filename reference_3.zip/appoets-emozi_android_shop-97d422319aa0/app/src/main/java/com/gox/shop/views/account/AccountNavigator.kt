package com.gox.shop.views.account

interface AccountNavigator{
    fun onMenuItemClicked(position: Int)

}