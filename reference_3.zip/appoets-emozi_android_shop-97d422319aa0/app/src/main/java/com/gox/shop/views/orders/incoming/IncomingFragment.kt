package com.gox.shop.views.orders.incoming

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.provider.SyncStateContract
import android.util.Log
import android.view.View
import androidx.databinding.ViewDataBinding
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.gox.shop.R
import com.gox.shop.base.BaseFragment
import com.gox.shop.databinding.FragmentIncomingOrdersBinding
import com.gox.shop.datamodel.CommonErrorResponse
import com.gox.shop.datamodel.NewOrderModel
import com.gox.shop.socket.SocketManager
import com.gox.shop.utils.Constants
import com.gox.shop.utils.PreferenceKey
import com.gox.shop.utils.SessionManager
import com.gox.shop.views.adapters.IncomingOrderAdapter
import com.gox.shop.views.dashboard.DashboardNavigator
import com.gox.shop.views.login.LoginActivity
import io.socket.emitter.Emitter
import kotlinx.android.synthetic.*
import javax.inject.Inject

class IncomingFragment : BaseFragment<FragmentIncomingOrdersBinding>(), IncomingNavigator {
    private lateinit var fragmentIncomingOrdersBinding: FragmentIncomingOrdersBinding
    private lateinit var incomingViewModel: IncomingViewModel
    private lateinit var dashboardNavigator: DashboardNavigator
    private lateinit var ctx: Context

    private lateinit var mPlayer: MediaPlayer

    @Inject
    lateinit var sessionManager: SessionManager

    override fun getLayoutId(): Int {
        return R.layout.fragment_incoming_orders
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        dashboardNavigator = context as DashboardNavigator
    }

    override fun initView(mRootView: View?, mViewDataBinding: ViewDataBinding?) {
        fragmentIncomingOrdersBinding = mViewDataBinding as FragmentIncomingOrdersBinding
        incomingViewModel = ViewModelProviders.of(this).get(IncomingViewModel::class.java)
        fragmentIncomingOrdersBinding.incomingViewModel = incomingViewModel
        fragmentIncomingOrdersBinding.setLifecycleOwner(this)
        incomingViewModel.navigator = this

        mPlayer = MediaPlayer.create(context, R.raw.alert_tone)

        if (dashboardNavigator != null)
            dashboardNavigator.setTitle(resources.getString(R.string.title_home))
        dashboardNavigator.hideLeftIcon(true)
        dashboardNavigator.hideRightIcon(true)
        ctx = activity!!
        getApiResponse()
        incomingViewModel.getIncomingOrders()
        SocketManager.emit(Constants.RoomName.JOINSHOPROOM, Constants.RoomID.TRANSPORT_ROOM)
        SocketManager.onEvent(Constants.RoomName.NEW_REQ, Emitter.Listener {
            Log.e("SOCKET", "SOCKET_SK transport STATUS ")
            incomingViewModel.getIncomingOrders()
        })
    }

    override fun onResume() {
        super.onResume()
        incomingViewModel.getIncomingOrders()

       if(incomingViewModel.newOrderLiveData.value!=null) {
           mPlayer.start()
       }
    }

    fun getApiResponse() {
        incomingViewModel.newOrderLiveData.observe(this, Observer<NewOrderModel> {
            if (it != null){
                mPlayer.start()
                when (it.statusCode!!.toInt()) {
                    Constants.StatusCode.SUCCESS -> {
                        if (!it.responseData.isNullOrEmpty()) {
                            fragmentIncomingOrdersBinding.rvIncomingOrders.visibility = View.VISIBLE
                            val incomingOrderAdapter =
                                IncomingOrderAdapter(incomingViewModel, ctx!!, it)
                            fragmentIncomingOrdersBinding.rvIncomingOrders.setAdapter(
                                incomingOrderAdapter
                            )
                            fragmentIncomingOrdersBinding.rvIncomingOrders.adapter!!.notifyDataSetChanged()
                            fragmentIncomingOrdersBinding.emptyViewLayout.visibility = View.GONE

                        } else {
                            mPlayer.stop()
                            fragmentIncomingOrdersBinding.rvIncomingOrders.visibility = View.GONE
                            fragmentIncomingOrdersBinding.emptyViewLayout.visibility = View.VISIBLE
                        }
                    }
                }
            }else{
                mPlayer.stop()
            }

               /* //Store type set
                sessionManager.put(PreferenceKey.SHOP_TYPE,""+it.responseData?.get(0).)
                sessionManager.sharedPreferences.edit().commit()*/

        })

    }

    override fun showError(message: String, statusCode: Int) {
        when (statusCode) {
            Constants.StatusCode.UNAUTHORIZED -> {
                val intent = Intent(activity, LoginActivity::class.java)
                startActivity(intent)
                activity!!.finish()
            }
        }

        mPlayer.stop()
    }

    override fun onPause() {
        super.onPause()
        mPlayer.pause()
    }

    override fun onDetach() {
        super.onDetach()
        mPlayer.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        mPlayer.stop()
    }


}