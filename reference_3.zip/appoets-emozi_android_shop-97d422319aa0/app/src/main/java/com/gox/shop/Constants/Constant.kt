package com.gox.shop.Constants

object Constant {

    const val COUNTRYCODE_PICKER_REQUEST_CODE = 111
    const val COUNTRYLIST_REQUEST_CODE = 100
    const val CITYLIST_REQUEST_CODE = 102



}