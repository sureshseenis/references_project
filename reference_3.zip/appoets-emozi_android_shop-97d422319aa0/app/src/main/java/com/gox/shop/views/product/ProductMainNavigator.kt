package com.gox.shop.views.product

interface ProductMainNavigator {
    fun setProductMainAdapter()
}