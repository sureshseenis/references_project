package com.gox.shop.views.citylist

interface CityListNavigator {
    fun closeActivity()
}