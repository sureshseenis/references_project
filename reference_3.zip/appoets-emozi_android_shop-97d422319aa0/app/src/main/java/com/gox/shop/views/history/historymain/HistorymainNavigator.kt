package com.gox.shop.views.history.historymain

interface  HistorymainNavigator{

}