package com.gox.shop.views.orderdetail

interface OrderDetailNavigator{

}