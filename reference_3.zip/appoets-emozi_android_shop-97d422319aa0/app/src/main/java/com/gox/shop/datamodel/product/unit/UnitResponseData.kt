package com.gox.shop.datamodel.product.unit

data class UnitResponseData(
    val error: List<Any>,
    val message: String,
    val responseData: ResponseData,
    val statusCode: String,
    val title: String
){
    data class ResponseData(
        val current_page: Int,
        val `data`: List<Data>,
        val first_page_url: String,
        val from: Int,
        val last_page: Int,
        val last_page_url: String,
        val next_page_url: String,
        val path: String,
        val per_page: Int,
        val prev_page_url: Any,
        val to: Int,
        val total: Int
    )

    data class Data(
        val company_id: Int,
        val created_at: Any,
        val created_by: Any,
        val created_type: String,
        val deleted_by: Any,
        val deleted_type: Any,
        val id: Int,
        val modified_by: Any,
        val modified_type: String,
        val name: String,
        val updated_at: Any
    )
}