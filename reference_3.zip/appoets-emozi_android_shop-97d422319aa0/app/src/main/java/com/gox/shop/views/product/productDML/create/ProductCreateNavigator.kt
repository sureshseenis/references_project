package com.gox.shop.views.product.productDML.create

interface ProductCreateNavigator {
    fun showError(errorMsg:String)

}