package com.gox.shop.views.history.historycancelled

interface  FragmentCancelNavigator {

}