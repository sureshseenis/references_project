package com.gox.shop.datamodel

data class AccountMenuModel(var text: String, val resId: Int)