package com.gox.shop.views.adapters

interface CustomClickListner {
    fun onListClickListner()
}